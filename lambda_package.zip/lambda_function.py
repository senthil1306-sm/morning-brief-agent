﻿import json, logging
from datetime import datetime, timezone, timedelta
from config import USER_NAME
from bedrock_client import generate_morning_brief
from ses_client import send_morning_brief_email
from s3_client import save_brief_to_s3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info('Morning Brief Agent - Started')
    try:
        ist = timezone(timedelta(hours=5, minutes=30))
        now = datetime.now(ist)
        current_date = now.strftime('%B %d, %Y')
        day_name = now.strftime('%A')
        logger.info('Date: ' + day_name + ', ' + current_date)
        brief = generate_morning_brief(current_date, day_name)
        s3_key = save_brief_to_s3(brief, current_date)
        email_resp = send_morning_brief_email(brief, current_date)
        return {'statusCode': 200, 'body': {'message': 'Success', 's3_key': s3_key, 'email_id': email_resp.get('MessageId')}}
    except Exception as e:
        logger.error('Error: ' + str(e))
        return {'statusCode': 500, 'body': {'error': str(e)}}