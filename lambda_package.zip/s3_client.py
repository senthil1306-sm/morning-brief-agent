﻿import logging, boto3
from datetime import datetime
from config import S3_BUCKET_NAME, S3_PREFIX

logger = logging.getLogger(__name__)

def save_brief_to_s3(brief_content, date_str):
    timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    key = S3_PREFIX + timestamp + '_morning_brief.md'
    client = boto3.client('s3', region_name='us-east-1')
    client.put_object(Bucket=S3_BUCKET_NAME, Key=key, Body=brief_content.encode('utf-8'), ContentType='text/markdown')
    logger.info('Saved to S3: ' + key)
    return key
