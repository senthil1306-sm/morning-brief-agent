﻿import os

AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')
BEDROCK_MODEL_ID = os.environ.get('BEDROCK_MODEL_ID', 'amazon.nova-lite-v1:0')
BEDROCK_MAX_TOKENS = int(os.environ.get('BEDROCK_MAX_TOKENS', '2048'))
SENDER_EMAIL = os.environ.get('SENDER_EMAIL', 'senthilkumar@example.com')
RECIPIENT_EMAIL = os.environ.get('RECIPIENT_EMAIL', 'senthilkumar@example.com')
S3_BUCKET_NAME = os.environ.get('S3_BUCKET_NAME', 'morning-brief-agent-500696805174')
S3_PREFIX = os.environ.get('S3_PREFIX', 'briefs/')
USER_NAME = os.environ.get('USER_NAME', 'SENTHIL')
USER_TIMEZONE = os.environ.get('USER_TIMEZONE', 'Asia/Calcutta')
