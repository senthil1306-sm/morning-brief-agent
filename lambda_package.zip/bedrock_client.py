﻿import json, logging, boto3
from config import BEDROCK_MODEL_ID, BEDROCK_MAX_TOKENS, USER_NAME

logger = logging.getLogger(__name__)

def generate_morning_brief(current_date, day_name):
    prompt = 'You are a personal AI assistant. Create a morning briefing for ' + USER_NAME + '. Today is ' + day_name + ', ' + current_date + '. Include: 1. Good Morning Greeting 2. Todays Date 3. Top 3 Priorities 4. Suggested Schedule 7AM-9PM 5. Productivity Tip 6. Motivational Quote 7. Daily Goals. Make it energizing with emojis.'
    client = boto3.client('bedrock-runtime', region_name='us-east-1')
    response = client.converse(
        modelId=BEDROCK_MODEL_ID,
        messages=[{'role': 'user', 'content': [{'text': prompt}]}],
        inferenceConfig={'maxTokens': BEDROCK_MAX_TOKENS, 'temperature': 0.7}
    )
    result = ''
    for block in response['output']['message']['content']:
        if 'text' in block:
            result += block['text']
    logger.info('Brief generated successfully')
    return result
