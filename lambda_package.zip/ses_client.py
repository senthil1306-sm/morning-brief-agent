﻿import logging, boto3
from config import SENDER_EMAIL, RECIPIENT_EMAIL, USER_NAME

logger = logging.getLogger(__name__)

def send_morning_brief_email(brief_content, date_str):
    client = boto3.client('ses', region_name='us-east-1')
    subject = 'Good Morning ' + USER_NAME + '! Your Daily Brief - ' + date_str
    response = client.send_email(
        Source=SENDER_EMAIL,
        Destination={'ToAddresses': [RECIPIENT_EMAIL]},
        Message={
            'Subject': {'Data': subject, 'Charset': 'UTF-8'},
            'Body': {'Text': {'Data': brief_content, 'Charset': 'UTF-8'}}
        }
    )
    logger.info('Email sent successfully')
    return response
